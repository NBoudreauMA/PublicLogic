# PublicLogic / VAULT – Website Starter

A lightweight, GitHub Pages–ready starter for a simple marketing / docs site.

## 🔧 Quick start
1. Create a new GitHub repo (e.g., `publiclogic-site`).
2. Upload these files or push with git (instructions below).
3. In **Settings → Pages**, set **Build and deployment** to "GitHub Actions".
4. Push to `main` — GitHub Actions will publish to Pages automatically.
